const audioPath = "../voice/test5/";

const audioFiles = [
    new Audio(audioPath + "practice1.wav"),
    new Audio(audioPath + "practice2.wav"),
    new Audio(audioPath + "practice3.wav")
];

let currentLevel = 1;
const totalLevels = 3;

window.addEventListener("DOMContentLoaded", () => {
    UserInfoManager.init(() => {
        UserInfoManager.hideForm();
        document.querySelector(".test-area").style.display = "block";
    });
    
    const playBtn = document.getElementById("play-btn");
    const nextBtn = document.getElementById("next-btn");
    const currentLevelElement = document.getElementById("current-level");

    // 播放按钮事件
    playBtn.addEventListener("click", () => {
        // 播放当前题目音频
        audioFiles[currentLevel - 1].play();
        
        // 显示下一题按钮
        nextBtn.style.display = "block";
    });

    // 下一题按钮事件
    nextBtn.addEventListener("click", () => {
        // 进入下一个关卡
        currentLevel++;
        
        // 如果还有题目，更新显示并隐藏下一题按钮
        if (currentLevel <= totalLevels) {
            currentLevelElement.textContent = currentLevel;
            nextBtn.style.display = "none";
        } else {
            // 所有题目完成，隐藏按钮并显示完成消息
            nextBtn.style.display = "none";
            playBtn.style.display = "none";
            
            // 创建并显示完成消息
            const completionMessage = document.createElement("div");
            completionMessage.textContent = "测试结束，您已完成所有3道题目！";
            completionMessage.style.fontSize = "20px";
            completionMessage.style.color = "#333";
            completionMessage.style.textAlign = "center";
            completionMessage.style.marginTop = "20px";
            document.body.appendChild(completionMessage);
        }
    });
});