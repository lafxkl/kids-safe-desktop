// 音频文件路径配置
const audioPath = "../voice/voice1/3,9及training刺激/";

// 创建音频对象字典
const audioFiles = {
    intro: new Audio(audioPath + "导言1.wav"),
    a: { 1: new Audio(audioPath + "a1.wav"), 2: new Audio(audioPath + "a2.wav"), 3: new Audio(audioPath + "a3.wav"), 4: new Audio(audioPath + "a4.wav") },
    i: { 1: new Audio(audioPath + "i1.wav"), 2: new Audio(audioPath + "i2.wav"), 3: new Audio(audioPath + "i3.wav"), 4: new Audio(audioPath + "i4.wav") },
    u: { 1: new Audio(audioPath + "u1.wav"), 2: new Audio(audioPath + "u2.wav"), 3: new Audio(audioPath + "u3.wav"), 4: new Audio(audioPath + "u4.wav") },
    v: { 1: new Audio(audioPath + "ü1.wav"), 2: new Audio(audioPath + "ü2.wav"), 3: new Audio(audioPath + "ü3.wav"), 4: new Audio(audioPath + "ü4.wav") },
    e: { 1: new Audio(audioPath + "e1.wav"), 2: new Audio(audioPath + "e2.wav"), 3: new Audio(audioPath + "e3.wav"), 4: new Audio(audioPath + "e4.wav") },
    ai: { 1: new Audio(audioPath + "ai1.wav"), 2: new Audio(audioPath + "ai2.wav"), 3: new Audio(audioPath + "ai3.wav"), 4: new Audio(audioPath + "ai4.wav") },
    ao: { 1: new Audio(audioPath + "ao1.wav"), 2: new Audio(audioPath + "ao2.wav"), 3: new Audio(audioPath + "ao3.wav"), 4: new Audio(audioPath + "ao4.wav") },
    ei: { 1: new Audio(audioPath + "ei1.wav"), 2: new Audio(audioPath + "ei2.wav"), 3: new Audio(audioPath + "ei3.wav"), 4: new Audio(audioPath + "ei4.wav") },
};

// 游戏配置
const totalLevels = 30;

// 当前测试序列信息
let currentLevel = 1;
let currentSyllable;
let differentPosition;
let startTime; // 序列播放开始时间
let results = []; // 存储所有测试结果
let selectedVowel = "a"; // 默认选择元音a

// 初始化页面元素事件
window.addEventListener("DOMContentLoaded", () => {
    // 初始化用户信息管理器
    UserInfoManager.init((userInfo) => {
        UserInfoManager.hideForm();
        const welcomeScreen = document.querySelector(".welcome-screen");
        welcomeScreen.style.display = "block";
        audioFiles.intro.play();
    });
    
    // 设置总关卡数
    const totalLevelsElement = document.getElementById("total-levels");
    totalLevelsElement.textContent = totalLevels;

    // 更新当前关卡显示
    updateLevelDisplay();

    // 导言音频播放结束后显示进入测试按钮
    audioFiles.intro.addEventListener("ended", () => {
        const enterTestBtn = document.getElementById("enter-test-btn");
        enterTestBtn.style.display = "block";
    });

    // 进入测试按钮事件
    const enterTestBtn = document.getElementById("enter-test-btn");
    enterTestBtn.addEventListener("click", () => {
        // 隐藏欢迎界面，显示测试区域
        const welcomeScreen = document.querySelector(".welcome-screen");
        const testArea = document.querySelector(".test-area");
        welcomeScreen.style.display = "none";
        testArea.style.display = "block";
        
        // 获取用户选择的元音
        selectedVowel = document.getElementById("vowel-select").value;
        
        // 生成并播放第一个测试序列
        generateSequence();
        playSequence();
    });

    // 播放按钮事件
    const playBtn = document.getElementById("play-btn");
    playBtn.addEventListener("click", () => {
        generateSequence();
        playSequence();
    });

    // 选项卡片事件
    const optionCards = document.querySelectorAll(".option-card");
    optionCards.forEach(card => {
        card.addEventListener("click", () => {
            const selectedOption = card.dataset.option;
            checkAnswer(selectedOption);
        });
    });
});

// 更新关卡显示
function updateLevelDisplay() {
    const currentLevelElement = document.getElementById("current-level");
    currentLevelElement.textContent = currentLevel;}

// 检查是否已完成所有关卡
function isGameCompleted() {
    return currentLevel > totalLevels;
}

// 生成测试序列
function generateSequence() {
    // 使用用户选择的元音作为当前音节
    currentSyllable = selectedVowel;

    // 随机决定不同的声音位置 (2: 中间, 3: 最后)
    differentPosition = Math.random() < 0.5 ? 2 : 3;
}

// 播放测试序列
function playSequence() {
    const audio = audioFiles[currentSyllable];
    const tone1 = audio[1];

    // 确保tone1存在
    if (!tone1) {
        generateSequence();
        playSequence();
        return;
    }

    // 记录序列播放开始时间
    startTime = Date.now();

    // 播放第一个声音 (固定为声调1)
    tone1.play();

    // 播放第二个声音
    tone1.addEventListener("ended", function playSecondSound() {
        // 移除事件监听器，避免重复触发
        tone1.removeEventListener("ended", playSecondSound);
        
        if (differentPosition === 2) {
            // 中间声音不同，随机选择其他声调
            const otherTones = [2, 3, 4];
            const randomTone = otherTones[Math.floor(Math.random() * otherTones.length)];
            const secondAudio = audio[randomTone];
            secondAudio.play();
            
            // 播放第三个声音
            secondAudio.addEventListener("ended", function playThirdSound() {
                secondAudio.removeEventListener("ended", playThirdSound);
                // 最后声音相同，播放声调1
                tone1.cloneNode(true).play();
            });
        } else {
            // 中间声音相同，播放声调1
            const secondAudio = tone1.cloneNode(true);
            secondAudio.play();
            
            // 播放第三个声音
            secondAudio.addEventListener("ended", function playThirdSound() {
                secondAudio.removeEventListener("ended", playThirdSound);
                
                if (differentPosition === 3) {
                    // 最后声音不同，随机选择其他声调
                    const otherTones = [2, 3, 4];
                    const randomTone = otherTones[Math.floor(Math.random() * otherTones.length)];
                    audio[randomTone].play();
                } else {
                    // 最后声音相同，播放声调1
                    tone1.cloneNode(true).play();
                }
            });
        }
    });
}

// 检查回答
function checkAnswer(selected) {
    const correctOption = differentPosition === 2 ? "middle" : "last";
    const resultDiv = document.getElementById("result");
    
    // 记录用户选择结束时间并计算反应时间
    const endTime = Date.now();
    const reactionTime = endTime - startTime;
    
    // 记录音频名字（音节）
    const audioName = currentSyllable;
    
    // 判断回答是否正确
    const isCorrect = selected === correctOption;
    
    // 存储结果
    results.push({
        level: currentLevel,
        audioName: audioName,
        correct: isCorrect,
        reactionTime: reactionTime
    });

    if (isCorrect) {
        resultDiv.textContent = "回答正确！太棒了！";
        resultDiv.className = "result correct";
    } else {
        resultDiv.textContent = "回答错误！";
        resultDiv.className = "result wrong";
    }
    
    // 无论正确与否，都进入下一个关卡
    setTimeout(() => {
        currentLevel++;
        updateLevelDisplay();
        resultDiv.textContent = "";
        resultDiv.className = "result";
        
        // 检查游戏是否已完成
        if (isGameCompleted()) {
            showCompletionMessage();
        } else {
            generateSequence();
            playSequence();
        }
    }, 1500);
}

// 显示游戏完成消息
function showCompletionMessage() {
    const resultDiv = document.getElementById("result");
    resultDiv.textContent = `恭喜你完成了所有${totalLevels}个关卡！太棒了！正在生成测试结果...`;
    resultDiv.className = "result correct";
    
    // 隐藏播放按钮
    const playBtn = document.getElementById("play-btn");
    playBtn.style.display = "none";
    
    // 隐藏选项卡片
    const optionCards = document.querySelector(".option-cards");
    optionCards.style.display = "none";
    
    // 生成并下载CSV文件
    generateCSV();
}

// 生成CSV文件
function generateCSV() {
    const BOM = "\uFEFF";
    let csvContent = BOM + "Name,Gender,Age,Level,AudioName,Correct,ReactionTime\n";
    
    results.forEach(e => {
        const row = UserInfoManager.generateCSVRow([
            e.level,
            e.audioName,
            e.correct,
            e.reactionTime
        ]);
        csvContent += row + "\n";
    });
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "test2_results.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}