// 题目数组，将从 JSON文件加载
let questions = [];

// 当前题目索引
let currentQuestionIndex = 0;

// 结果记录数组
const results = [];

// 音频对象
let audioElement1 = new Audio();
let audioElement2 = new Audio();

// 题目直接内联在 index.html 的 window.__NSFD_QUESTIONS__，离线可用（file:// 下 fetch 会被同源策略拦截）
function loadQuestions() {
    questions = window.__NSFD_QUESTIONS__ || [];
    questions = shuffleArray(questions);
    console.log('题目加载成功，共', questions.length, '题，顺序已打乱');
    return questions;
}

// Fisher-Yates 洗牌算法，用于随机打乱数组顺序
function shuffleArray(array) {
    const shuffled = [...array]; // 创建数组副本，避免修改原始数组
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        // 交换元素
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

// 页面加载完成后初始化
window.addEventListener('load', async () => {
    UserInfoManager.init(() => {
        UserInfoManager.hideForm();
        document.getElementById("introduction-section").style.display = "block";
    });
    
    // 设置介绍部分的音频播放功能
    setupIntroductionAudio();
});

// 监听测试开始事件
window.addEventListener('testStart', async () => {
    // 测试页面逻辑
    // 先加载题目
    await loadQuestions();
    initPage();
    
    // 自动播放当前题目的两个音频
    playAudioSequence();
    
    // 下一题按钮事件
    const nextQuestionBtn = document.getElementById('next-question-btn');
    if (nextQuestionBtn) {
        nextQuestionBtn.addEventListener('click', nextQuestion);
    }
    
    // 图片点击事件
    const leftImage = document.getElementById('left-image');
    const rightImage = document.getElementById('right-image');
    if (leftImage && rightImage) {
        leftImage.addEventListener('click', () => recordAnswer('left'));
        rightImage.addEventListener('click', () => recordAnswer('right'));
    }
});

// 设置介绍部分的音频播放功能
function setupIntroductionAudio() {
    const playAudioBtn = document.getElementById('play-audio-btn');
    const instructionAudio = document.getElementById('instruction-audio');
    
    // 播放音频按钮事件
    if (playAudioBtn && instructionAudio) {
        let isPlaying = false;
        
        playAudioBtn.addEventListener('click', () => {
            if (isPlaying) {
                instructionAudio.pause();
                instructionAudio.currentTime = 0;
                playAudioBtn.innerHTML = '<span class="audio-icon">▶</span> 播放测试说明';
            } else {
                instructionAudio.play()
                    .then(() => {
                        playAudioBtn.innerHTML = '<span class="audio-icon">⏸</span> 暂停测试说明';
                        isPlaying = true;
                        
                        // 音频播放结束时重置按钮
                        instructionAudio.onended = () => {
                            playAudioBtn.innerHTML = '<span class="audio-icon">▶</span> 播放测试说明';
                            isPlaying = false;
                        };
                    })
                    .catch(error => {
                        console.error('音频播放失败:', error);
                        alert('音频播放失败，请检查浏览器权限设置。');
                    });
            }
        });
    }
}

// 初始化页面
function initPage() {
    showQuestion();
}

// 显示当前题目
function showQuestion() {
    const question = questions[currentQuestionIndex];
    
    // 显示题目信息
    const levelInfo = document.getElementById('level-info');
    levelInfo.textContent = `第${currentQuestionIndex + 1}题，共${questions.length}题`;
    
    // 设置图片
    const centerImage = document.getElementById('center-image');
    const leftImage = document.getElementById('left-image');
    const rightImage = document.getElementById('right-image');
    
    centerImage.src = question.centerImage;
    leftImage.src = question.leftToneImage;
    rightImage.src = question.rightToneImage;
    
    // 设置音频
    audioElement1.src = question.audio1;
    audioElement2.src = question.audio2;
}

// 依次播放两个音频
function playAudioSequence() {
    // 先播放第一个音频
    audioElement1.play()
        .then(() => {
            // 第一个音频播放结束后播放第二个音频
            return new Promise((resolve) => {
                audioElement1.onended = resolve;
            });
        })
        .then(() => {
            return audioElement2.play();
        })
        .catch(error => {
            console.error('音频播放失败:', error);
        });
}

// 记录用户答案并添加视觉反馈
function recordAnswer(selectedSide) {
    // 检查当前题目是否已经有答案记录，防止重复选择
    const currentQuestionNumber = currentQuestionIndex + 1;
    const alreadyAnswered = results.some(result => result.questionIndex === currentQuestionNumber);
    
    if (alreadyAnswered) {
        console.log(`题目 ${currentQuestionNumber} 已经回答过了`);
        return; // 已经回答过的题目不再记录
    }
    
    const question = questions[currentQuestionIndex];
    // 使用JSON中定义的correctAnswer字段作为正确答案
    const isCorrect = selectedSide === question.correctAnswer;
    
    const result = {
        questionIndex: currentQuestionNumber,
        selected: selectedSide,
        isCorrect: isCorrect,
        time: Date.now()
    };
    
    results.push(result);
    
    // 添加视觉反馈 - 高亮选中的图片
    const leftImage = document.getElementById('left-image');
    const rightImage = document.getElementById('right-image');
    
    if (selectedSide === 'left') {
        leftImage.classList.add('selected');
    } else {
        rightImage.classList.add('selected');
    }
    
    // 禁止再次点击图片
    leftImage.style.pointerEvents = 'none';
    rightImage.style.pointerEvents = 'none';
    
    console.log(`题目 ${currentQuestionNumber} 答案记录: 选择${selectedSide}, ${isCorrect ? '正确' : '错误'}`);
}

// 下一题
function nextQuestion() {
    currentQuestionIndex++;
    
    if (currentQuestionIndex < questions.length) {
        // 重置图片状态
        const leftImage = document.getElementById('left-image');
        const rightImage = document.getElementById('right-image');
        
        // 移除选中样式
        leftImage.classList.remove('selected');
        rightImage.classList.remove('selected');
        
        // 恢复点击事件
        leftImage.style.pointerEvents = 'auto';
        rightImage.style.pointerEvents = 'auto';
        
        // 显示下一题
        showQuestion();
        
        // 自动播放音频
        playAudioSequence();
    } else {
        // 所有题目完成，生成结果
        generateResult();
    }
}

// 生成并保存结果
function generateResult() {
    // 计算正确率
    const correctCount = results.filter(result => result.isCorrect).length;
    const totalCount = questions.length;
    const accuracy = (correctCount / totalCount * 100).toFixed(2);
    
    // 显示结果
    alert(`所有题目完成！\n总题数：${totalCount}\n正确题数：${correctCount}\n正确率：${accuracy}%`);
    
    // 生成CSV
    const csvContent = generateCSV(results);
    downloadCSV(csvContent, 'test7_results.csv');
}

// 生成CSV文件内容
function generateCSV(results) {
    const BOM = "\uFEFF";
    let csv = BOM + 'Name,Gender,Age,题目序号,选择,是否正确,时间戳\n';
    results.forEach(result => {
        csv += UserInfoManager.generateCSVRow([
            result.questionIndex,
            result.selected,
            result.isCorrect ? '是' : '否',
            result.time
        ]) + '\n';
    });
    return csv;
}

// 下载CSV文件
function downloadCSV(csv, filename) {
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename);
    
    document.body.appendChild(link);
    link.click();
    
    document.body.removeChild(link);
}