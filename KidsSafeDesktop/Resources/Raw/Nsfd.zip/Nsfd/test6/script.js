// test6/script.js

// 配置音频路径
const instructionAudioPath = '../voice/test6/instruction6.wav';
const audio = new Audio();

// 记录测试结果
const results = [];
let startTime = 0; // 计时器开始时间

// 定义题目顺序和答案
// 题目: [图片URL1, 图片URL2, 音频URL, 正确答案选项]
// 答案选项: 1 = 第一个选项, 2 = 第二个选项
const questions = [
    ['../picture/test6/cat.jpg', '../picture/test6/fork.jpg', '../voice/test6/stress_sent1.wav', 2],
    ['../picture/test6/duck.jpg', '../picture/test6/cup.jpg', '../voice/test6/stress_sent4.wav', 2],
    ['../picture/test6/pig.jpg', '../picture/test6/cup.jpg', '../voice/test6/stress_sent6.wav', 1],
    ['../picture/test6/cat.jpg', '../picture/test6/knife.jpg', '../voice/test6/stress_sent2.wav', 1],
    ['../picture/test6/duck.jpg', '../picture/test6/knife.jpg', '../voice/test6/stress_sent5.wav', 1],
    ['../picture/test6/cat.jpg', '../picture/test6/knife.jpg', '../voice/test6/stress_sent3.wav', 2],
    ['../picture/test6/pig.jpg', '../picture/test6/cup.jpg', '../voice/test6/stress_sent7.wav', 2],
    ['../picture/test6/pig.jpg', '../picture/test6/fork.jpg', '../voice/test6/stress_sent8.wav', 1],
];

let currentQuestionIndex = 0;
let selectedAnswer = null;
let isAnswered = false;

// 获取页面元素
const currentLevelSpan = document.getElementById('current-level');
const totalLevelsSpan = document.getElementById('total-levels');
const image1 = document.getElementById('image1');
const image2 = document.getElementById('image2');
const playBtn = document.getElementById('play-btn');
const nextBtn = document.getElementById('next-btn');

// 初始化页面
function initPage() {
    totalLevelsSpan.textContent = questions.length;
    loadQuestion(currentQuestionIndex);
}

// 加载题目
function loadQuestion(questionIndex) {
    if (questionIndex >= questions.length) {
        // 所有题目完成
        endTest();
        return;
    }

    const question = questions[questionIndex];
    image1.src = question[0];
    image2.src = question[1];
    
    // 重置状态
    selectedAnswer = null;
    isAnswered = false;
    nextBtn.style.display = 'none';
    playBtn.textContent = '播放声音';
    
    // 更新当前题目显示
    currentLevelSpan.textContent = questionIndex + 1;
    currentQuestionIndex = questionIndex;
}

// 播放当前题目的音频
playBtn.addEventListener('click', () => {
    if (currentQuestionIndex < questions.length) {
        const question = questions[currentQuestionIndex];
        audio.src = question[2];
        startTime = Date.now(); // 开始计时
        audio.play();
    }
});

// 处理图片点击选择答案
image1.addEventListener('click', () => {
    if (isAnswered) return;
    selectedAnswer = 1;
    const reactionTime = Date.now() - startTime;
    checkAnswer(reactionTime);
});

image2.addEventListener('click', () => {
    if (isAnswered) return;
    selectedAnswer = 2;
    const reactionTime = Date.now() - startTime;
    checkAnswer(reactionTime);
});

// 检查答案
function checkAnswer(reactionTime) {
    if (!selectedAnswer) return;
    
    const question = questions[currentQuestionIndex];
    const correctAnswer = question[3];
    const isCorrect = selectedAnswer === correctAnswer;
    const stress = correctAnswer === 1 ? 'S' : 'O';
    
    // 记录测试结果
    const result = {
        trial_i: currentQuestionIndex + 1,
        Task: 'stress_sen',
        Stress: stress,
        retry_n: 1,
        choice: `${currentQuestionIndex + 1} opt-${selectedAnswer === 1 ? 'S' : 'O'}`,
        correct: isCorrect ? 1 : 0,
        react_time: reactionTime
    };
    results.push(result);
    
    isAnswered = true;
    
    if (isCorrect) {
        // 回答正确
        playBtn.textContent = '回答正确!';
    } else {
        // 回答错误
        playBtn.textContent = '回答错误!';
    }
    
    // 显示下一题按钮
    nextBtn.style.display = 'block';
}

// 下一题
nextBtn.addEventListener('click', () => {
    currentQuestionIndex++;
    loadQuestion(currentQuestionIndex);
});

// 结束测试
function endTest() {
    playBtn.textContent = '测试完成!';
    nextBtn.style.display = 'none';
    generateCSV();
}

// 生成CSV文件
function generateCSV() {
    const BOM = "\uFEFF";
    const headers = ['Name', 'Gender', 'Age', 'trial_i', 'Task', 'Stress', 'retry_n', 'choice', 'correct', 'react_time'];
    const rows = results.map(result => [
        result.trial_i,
        result.Task,
        result.Stress,
        result.retry_n,
        result.choice,
        result.correct,
        result.react_time
    ]);
    let csvContent = BOM + headers.join(',') + '\n';
    rows.forEach(row => {
        csvContent += UserInfoManager.generateCSVRow(row) + '\n';
    });
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'test6_results.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// 页面加载完成后初始化
window.addEventListener('load', () => {
    UserInfoManager.init(() => {
        UserInfoManager.hideForm();
        document.querySelector(".test-area").style.display = "block";
        initPage();
    });
});