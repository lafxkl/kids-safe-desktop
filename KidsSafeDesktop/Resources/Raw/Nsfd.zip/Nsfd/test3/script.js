// 音频文件路径配置
const audioPath = "../voice/voice1/3,9及training刺激/";

// 创建音频对象字典
const audioFiles = {
    intro: new Audio(audioPath + "导言12.wav"),
    a: { 1: new Audio(audioPath + "a1.wav"), 2: new Audio(audioPath + "a2.wav"), 3: new Audio(audioPath + "a3.wav"), 4: new Audio(audioPath + "a4.wav") },
    i: { 1: new Audio(audioPath + "i1.wav"), 2: new Audio(audioPath + "i2.wav"), 3: new Audio(audioPath + "i3.wav"), 4: new Audio(audioPath + "i4.wav") },
    u: { 1: new Audio(audioPath + "u1.wav"), 2: new Audio(audioPath + "u2.wav"), 3: new Audio(audioPath + "u3.wav"), 4: new Audio(audioPath + "u4.wav") },
    v: { 1: new Audio(audioPath + "ü1.wav"), 2: new Audio(audioPath + "ü2.wav"), 3: new Audio(audioPath + "ü3.wav"), 4: new Audio(audioPath + "ü4.wav") },
    e: { 1: new Audio(audioPath + "e1.wav"), 2: new Audio(audioPath + "e2.wav"), 3: new Audio(audioPath + "e3.wav"), 4: new Audio(audioPath + "e4.wav") },
   
};

// 游戏配置
const totalLevels = 60;

// 当前测试信息
let currentLevel = 1;
let currentSyllable;
let currentTone;
let startTime;
let results = [];

// 初始化页面元素事件
window.addEventListener("DOMContentLoaded", () => {
    UserInfoManager.init((userInfo) => {
        UserInfoManager.hideForm();
        document.querySelector(".welcome-screen").style.display = "block";
        audioFiles.intro.play();
    });
    
    // 设置总关卡数
    const totalLevelsElement = document.getElementById("total-levels");
    totalLevelsElement.textContent = totalLevels;

    // 更新当前关卡显示
    updateLevelDisplay();

    // 导言音频播放结束后显示进入测试按钮
    audioFiles.intro.addEventListener("ended", () => {
        const enterTestBtn = document.getElementById("enter-test-btn");
        enterTestBtn.style.display = "block";
    });

    // 进入测试按钮事件
    const enterTestBtn = document.getElementById("enter-test-btn");
    enterTestBtn.addEventListener("click", () => {
        // 隐藏欢迎界面，显示测试区域
        const welcomeScreen = document.querySelector(".welcome-screen");
        const testArea = document.querySelector(".test-area");
        welcomeScreen.style.display = "none";
        testArea.style.display = "block";
        
        // 生成并播放第一个测试
        generateRandomTone();
    });

    // 播放按钮事件
    const playBtn = document.getElementById("play-btn");
    playBtn.addEventListener("click", () => {
        generateRandomTone();
    });

    // 选项卡片事件
    const optionCards = document.querySelectorAll(".option-card");
    optionCards.forEach(card => {
        card.addEventListener("click", () => {
            const selectedTone = parseInt(card.dataset.option);
            checkAnswer(selectedTone);
        });
    });
});

// 更新关卡显示
function updateLevelDisplay() {
    const currentLevelElement = document.getElementById("current-level");
    currentLevelElement.textContent = currentLevel;
}

// 检查是否已完成所有关卡
function isGameCompleted() {
    return currentLevel > totalLevels;
}

// 生成随机声调并播放
function generateRandomTone() {
    // 随机选择一个音节（排除intro）
    const syllables = Object.keys(audioFiles).filter(key => key !== "intro");
    currentSyllable = syllables[Math.floor(Math.random() * syllables.length)];

    // 随机选择一个声调
    currentTone = Math.floor(Math.random() * 4) + 1;

    // 播放音频
    playTone();
}

// 播放当前选择的声调
function playTone() {
    const audio = audioFiles[currentSyllable][currentTone];
    if (audio) {
        audio.play();
        startTime = Date.now(); // 记录播放开始时间
    } else {
        console.error("Audio file not found");
    }
}
// 检查回答
function checkAnswer(selected) {
    const resultDiv = document.getElementById("result");
    
    // 记录用户选择结束时间并计算反应时间
    const endTime = Date.now();
    const reactionTime = endTime - startTime;
    
    // 记录音频信息
    const audioInfo = {
        syllable: currentSyllable,
        tone: currentTone,
        audioName: `${currentSyllable}${currentTone}.wav`
    };
    
    // 判断回答是否正确
    const isCorrect = selected === currentTone;
    
    // 存储结果
    results.push({
        level: currentLevel,
        audio: audioInfo,
        selected: selected,
        correct: isCorrect,
        reactionTime: reactionTime
    });

    if (isCorrect) {
        resultDiv.textContent = "回答正确！太棒了！";
        resultDiv.className = "result correct";
        
        // 进入下一个关卡
        setTimeout(() => {
            currentLevel++;
            updateLevelDisplay();
            resultDiv.textContent = "";
            resultDiv.className = "result";
            
            // 检查游戏是否已完成
            if (isGameCompleted()) {
                showCompletionMessage();
            } else {
                generateRandomTone(); // 进入下一关
            }
        }, 1500);
    } else {
        resultDiv.textContent = "回答错误，再试一次吧！";
        resultDiv.className = "result wrong";
    }
}

// 显示测试完成消息
function showCompletionMessage() {
    const correctAnswers = results.filter(result => result.correct).length;
    const totalQuestions = results.length;
    const accuracy = Math.round((correctAnswers / totalQuestions) * 100);
    const totalReactionTime = results.reduce((sum, result) => sum + result.reactionTime, 0);
    const averageReactionTime = Math.round(totalReactionTime / totalQuestions);

    const resultDiv = document.getElementById("result");
    resultDiv.innerHTML = `
        <h2>测试完成！</h2>
        <p>总题目数: ${totalQuestions}</p>
        <p>答对题数: ${correctAnswers}</p>
        <p>准确率: ${accuracy}%</p>
        <p>平均反应时间: ${averageReactionTime}毫秒</p>
    `;
    resultDiv.className = "result completed";
    
    // 隐藏播放按钮
    const playBtn = document.getElementById("play-btn");
    playBtn.style.display = "none";
    
    // 隐藏选项卡片
    const optionCards = document.querySelector(".option-cards");
    optionCards.style.display = "none";
    
    // 生成并下载CSV文件
    generateCSV();
}

// 生成CSV文件
function generateCSV() {
    const BOM = "\uFEFF";
    let csvContent = BOM + "Name,Gender,Age,Level,AudioName,Correct,ReactionTime\n";
    results.forEach(e => {
        csvContent += UserInfoManager.generateCSVRow([e.level, e.audio.audioName, e.correct, e.reactionTime]) + "\n";
    });
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "test3_results.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}