/**
 * 用户信息管理模块
 * 用于收集和管理用户的基本信息（姓名、性别、年龄）
 */

// 用户信息对象
const UserInfoManager = {
    // 存储用户信息
    userInfo: {
        name: '',
        gender: '',
        age: ''
    },
    
    // 初始化用户信息表单
    init: function(onSubmitCallback) {
        const submitBtn = document.getElementById('submit-user-info-btn');
        if (!submitBtn) {
            console.error('找不到提交按钮');
            return;
        }
        
        submitBtn.addEventListener('click', () => {
            if (this.validateForm()) {
                this.saveUserInfo();
                if (typeof onSubmitCallback === 'function') {
                    onSubmitCallback(this.userInfo);
                }
            }
        });
    },
    
    // 验证表单
    validateForm: function() {
        const name = document.getElementById('user-name').value.trim();
        const gender = document.getElementById('user-gender').value;
        const age = document.getElementById('user-age').value;
        
        if (!name) {
            alert('请输入姓名！');
            return false;
        }
        
        if (!gender) {
            alert('请选择性别！');
            return false;
        }
        
        if (!age || age < 1 || age > 120) {
            alert('请输入有效的年龄（1-120）！');
            return false;
        }
        
        return true;
    },
    
    // 保存用户信息
    saveUserInfo: function() {
        this.userInfo.name = document.getElementById('user-name').value.trim();
        this.userInfo.gender = document.getElementById('user-gender').value;
        this.userInfo.age = document.getElementById('user-age').value;
        
        console.log('用户信息已保存:', this.userInfo);
    },
    
    // 获取用户信息
    getUserInfo: function() {
        return this.userInfo;
    },
    
    // 隐藏用户信息表单
    hideForm: function() {
        const userInfoScreen = document.getElementById('user-info-screen');
        if (userInfoScreen) {
            userInfoScreen.style.display = 'none';
        }
    },
    
    // 显示用户信息表单
    showForm: function() {
        const userInfoScreen = document.getElementById('user-info-screen');
        if (userInfoScreen) {
            userInfoScreen.style.display = 'block';
        }
    },
    
    // 生成CSV行（包含用户信息）
    generateCSVRow: function(additionalData) {
        const escapeCsvValue = (value) => {
            if (value === null || value === undefined) return '';
            const strValue = String(value);
            // 如果包含逗号、引号或换行，需要用引号包裹并转义内部引号
            if (strValue.includes(',') || strValue.includes('"') || strValue.includes('\n')) {
                return '"' + strValue.replace(/"/g, '""') + '"';
            }
            return strValue;
        };
        
        const row = [
            escapeCsvValue(this.userInfo.name),
            escapeCsvValue(this.userInfo.gender),
            escapeCsvValue(this.userInfo.age)
        ];
        
        if (Array.isArray(additionalData)) {
            additionalData.forEach(data => row.push(escapeCsvValue(data)));
        }
        
        return row.join(',');
    }
};
