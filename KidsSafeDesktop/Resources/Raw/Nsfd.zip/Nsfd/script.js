// 页面加载完成后执行
window.addEventListener('DOMContentLoaded', function() {
    // 添加页面加载动画
    document.body.classList.add('loaded');
    
    // 为测试卡片添加交互效果
    const testCards = document.querySelectorAll('.test-card');
    
    testCards.forEach(card => {
        // 添加鼠标悬停效果
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px) scale(1.02)';
            this.style.boxShadow = '0 15px 30px rgba(0, 0, 0, 0.15)';
        });
        
        // 恢复正常状态
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
            this.style.boxShadow = '0 6px 16px rgba(0, 0, 0, 0.08)';
        });
        
        // 添加点击效果
        card.addEventListener('click', function(e) {
            // 创建点击波纹效果
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            ripple.classList.add('ripple');
            
            // 移除之前的波纹
            const currentRipples = this.querySelectorAll('.ripple');
            currentRipples.forEach(r => r.remove());
            
            this.appendChild(ripple);
        });
    });
    
    // 添加平滑滚动
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
    
    // 检查并提示浏览器兼容性
    checkBrowserCompatibility();
});

// 浏览器兼容性检查
function checkBrowserCompatibility() {
    // 简单的音频支持检查
    const audioSupported = 'Audio' in window;
    
    if (!audioSupported) {
        alert('您的浏览器可能不完全支持音频功能，某些测试可能无法正常进行。建议使用最新版本的Chrome、Firefox或Safari浏览器。');
    }
}

// 随机生成一个欢迎消息
function generateWelcomeMessage() {
    const messages = [
        '欢迎使用语音测试系统！',
        '准备好了吗？开始您的语音测试之旅吧！',
        '请选择一个测试开始挑战！',
        '提高您的语音识别能力，从这里开始。'
    ];
    
    const randomIndex = Math.floor(Math.random() * messages.length);
    return messages[randomIndex];
}

// 添加键盘快捷键支持
window.addEventListener('keydown', function(e) {
    // 数字键1-7可以快速跳转到对应测试
    if (e.key >= '1' && e.key <= '7') {
        const testNumber = e.key;
        window.location.href = `test${testNumber}/index.html`;
    }
});